# ==============================================================================
# Flickd AI Hackathon - Smart Tagging & Vibe Classification Engine
#
# This is the final, production-ready script.
# It processes videos and images to detect products and classify vibes.
# ==============================================================================

# FIX FOR OMP: Error #15 - This MUST be at the top of the script
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

# --- All other imports follow ---
import cv2
import json
import torch
import faiss
import pandas as pd
from PIL import Image
from ultralytics import YOLO
from transformers import CLIPProcessor, CLIPModel, pipeline
from tqdm import tqdm

# --- CONFIGURATION ---
# ------------------------------------------------------------------------------
# --- Paths ---
INPUT_MEDIA_DIR = 'development/data/media_inputs/'
OUTPUT_DIR = 'development/outputs/'
CAPTION_DIR = 'development/data/text_captions/'
FAISS_INDEX_PATH = 'development/models/catalog.index'
PRODUCT_MAP_PATH = 'development/models/product_map.json'
VIBES_LIST_PATH = 'development/data/vibeslist.json'

# --- Model Names ---
YOLO_MODEL_NAME = 'yolov8n.pt'
CLIP_MODEL_NAME = "openai/clip-vit-base-patch32"
NLP_MODEL_NAME = "facebook/bart-large-mnli"

# --- Thresholds & Tuning ---
YOLO_CONFIDENCE_THRESHOLD = 0.40
MATCH_SIMILARITY_THRESHOLD = 0.75
EXACT_MATCH_THRESHOLD = 0.90
VIBE_CONFIDENCE_THRESHOLD = 0.60 # Confidence for ML-based vibe classification

YOLO_CLASS_MAP = {
    'person': 'outfit',
    'handbag': 'bag',
    'backpack': 'bag',
    'tie': 'accessory',
    'hat': 'accessory'
}
# ------------------------------------------------------------------------------


# --- GLOBAL MODEL LOADING ---
# ------------------------------------------------------------------------------
print("Loading all AI models. This may take a moment...")
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

yolo_model = YOLO(YOLO_MODEL_NAME)
yolo_model.to(device)
clip_model = CLIPModel.from_pretrained(CLIP_MODEL_NAME).to(device)
clip_processor = CLIPProcessor.from_pretrained(CLIP_MODEL_NAME)
faiss_index = faiss.read_index(FAISS_INDEX_PATH)
product_map_df = pd.read_json(PRODUCT_MAP_PATH)
vibe_classifier = pipeline("zero-shot-classification", model=NLP_MODEL_NAME, device=device)
try:
    with open(VIBES_LIST_PATH, 'r') as f:
        VIBES_LIST = json.load(f)
except FileNotFoundError:
    print(f"ERROR: vibes_list.json not found at {VIBES_LIST_PATH}! Vibe classification will be disabled.")
    VIBES_LIST = []

print("All models loaded successfully.")
# ------------------------------------------------------------------------------


# --- HELPER FUNCTIONS ---
# ------------------------------------------------------------------------------
def get_frames_from_media(media_path):
    if media_path.lower().endswith(('.mp4', '.mov', '.avi')):
        frames = []
        cap = cv2.VideoCapture(media_path)
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(fps) if fps > 0 else 1
        frame_count = 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret: break
            if frame_count % frame_interval == 0:
                frames.append(Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)))
            frame_count += 1
        cap.release()
        return frames
    elif media_path.lower().endswith(('.png', '.jpg', '.jpeg')):
        return [Image.open(media_path).convert("RGB")]
    return []

def detect_and_crop_items(frames):
    detected_items = []
    results = yolo_model(frames, conf=YOLO_CONFIDENCE_THRESHOLD, verbose=False)
    for i, r in enumerate(results):
        for box in r.boxes:
            class_name = yolo_model.names[int(box.cls[0])]
            if class_name in YOLO_CLASS_MAP:
                bbox_coords = box.xyxy[0].cpu().numpy()
                cropped_image = frames[i].crop(bbox_coords)
                detected_items.append(cropped_image)
    return detected_items

def find_best_match(cropped_image):
    with torch.no_grad():
        inputs = clip_processor(images=cropped_image, return_tensors="pt").to(device)
        image_features = clip_model.get_image_features(**inputs)
        image_features /= image_features.norm(p=2, dim=-1, keepdim=True)
    query_embedding = image_features.cpu().numpy()
    distances, indices = faiss_index.search(query_embedding, k=1)
    match_index = indices[0][0]
    similarity = float(distances[0][0])
    if similarity >= MATCH_SIMILARITY_THRESHOLD:
        matched_product_details = product_map_df.iloc[match_index]
        return {"matched_product_id": int(matched_product_details['product_id']), "type": matched_product_details['category'], "color": matched_product_details['color'], "confidence": similarity}
    return None

def classify_vibes(caption_text, classifier, vibe_list):
    """
    [CORRECTED & FINAL VERSION] Classifies vibes from a caption.
    """
    if not caption_text or not caption_text.strip() or not vibe_list:
        return []

    # 1. Fast, Rule-Based Check for exact matches
    found_vibes = [vibe for vibe in vibe_list if vibe.lower() in caption_text.lower()]
    if found_vibes:
        return found_vibes[:3] # Return up to 3 direct matches

    # 2. ML-Based Fallback if no keywords were found
    try:
        result = classifier(caption_text, vibe_list, multi_label=True)
        
        # Filter vibes that meet our confidence threshold
        confident_vibes = [
            label for label, score in zip(result['labels'], result['scores']) 
            if score > VIBE_CONFIDENCE_THRESHOLD
        ]
        
        # Logic to ensure we always return 1-3 vibes as per hackathon rules
        if confident_vibes:
            # If we have confident results, return up to 3 of them
            return confident_vibes[:3]
        else:
            # If no vibe is confident enough, return the single best guess from the model
            return [result['labels'][0]]
            
    except Exception as e:
        print(f"  > WARNING: NLP model failed with an exception: {e}")
        return []
# ------------------------------------------------------------------------------


# --- MAIN EXECUTION ---
# ------------------------------------------------------------------------------
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    media_files = [f for f in os.listdir(INPUT_MEDIA_DIR)]

    for filename in tqdm(media_files, desc="Processing Media Files"):
        media_path = os.path.join(INPUT_MEDIA_DIR, filename)
        unique_base_id = filename.replace('.', '_')
        output_path = os.path.join(OUTPUT_DIR, f"{unique_base_id}.json")

        # Vibe Classification (only for videos with corresponding text files)
        vibes = []
        if filename.lower().endswith('.mp4'):
            original_base_name = os.path.splitext(filename)[0]
            caption_path = os.path.join(CAPTION_DIR, f"{original_base_name}.txt")
            try:
                with open(caption_path, 'r', encoding='utf-8') as f:
                    caption_text = f.read()
                vibes = classify_vibes(caption_text, vibe_classifier, VIBES_LIST)
            except FileNotFoundError:
                pass # This is expected if a video has no caption file

        # Visual Processing (for all media)
        frames = get_frames_from_media(media_path)
        if not frames:
            continue
        
        cropped_items = detect_and_crop_items(frames)
        
        # Product Matching and De-duplication
        final_products = {}
        for item_image in cropped_items:
            match = find_best_match(item_image)
            if match:
                pid = match['matched_product_id']
                if pid not in final_products or match['confidence'] > final_products[pid]['confidence']:
                    final_products[pid] = match
        
        # Format Product List for Output
        products_output_list = []
        for prod_id, prod_data in final_products.items():
            match_type = "exact" if prod_data['confidence'] >= EXACT_MATCH_THRESHOLD else "similar"
            products_output_list.append({"type": prod_data['type'],"color": prod_data['color'],"matched_product_id": prod_data['matched_product_id'],"match_type": match_type,"confidence": round(prod_data['confidence'], 2)})

        # Assemble and Save Final JSON
        output_data = {
            "video_id": unique_base_id,
            "vibes": vibes,
            "products": products_output_list
        }
        with open(output_path, 'w') as f:
            json.dump(output_data, f, indent=2)

if __name__ == "__main__":
    main()
# ------------------------------------------------------------------------------