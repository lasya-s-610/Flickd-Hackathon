# ==============================================================================
# Flickd AI Hackathon - Core Processing Logic
#
# Author: Lasya
# Date: 08/06/2025
#
# Description:
# This module contains the core machine learning pipeline for the Flickd AI
# engine. It is designed to be imported by other scripts, such as a web app
# (`app.py`) or a batch processing script.
#
# The main function, `run_full_pipeline`, orchestrates the entire process from
# frame extraction to final JSON output.
# ==============================================================================

# --- Library Imports ---
import os
import cv2
import torch
import faiss
import numpy as np
import pandas as pd
from PIL import Image
from ultralytics import YOLO
from transformers import CLIPProcessor, CLIPModel, pipeline

# Solves a common library conflict with PyTorch and Intel's MKL on some systems.
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# --- Configuration Constants ---
YOLO_CONFIDENCE_THRESHOLD = 0.40
MATCH_SIMILARITY_THRESHOLD = 0.75
EXACT_MATCH_THRESHOLD = 0.90
# Maps general YOLO classes to broader, relevant fashion categories.
YOLO_CLASS_MAP = {
    'person': 'outfit',
    'handbag': 'bag',
    'backpack': 'bag',
    'tie': 'accessory',
    'hat': 'accessory'
}


# ==============================================================================
# 1. MAIN PIPELINE ORCHESTRATOR
# ==============================================================================
def run_full_pipeline(media_path, models, caption_text=""):
    """
    Executes the end-to-end media processing pipeline.

    Args:
        media_path (str): The file path of the input video or image.
        models (dict): A dictionary containing all pre-loaded AI models.
        caption_text (str, optional): The text caption for vibe classification.

    Returns:
        dict: A dictionary containing the structured analysis results.
    """
    # Unpack the pre-loaded models for cleaner access.
    yolo_model = models['yolo']
    clip_model = models['clip']
    clip_processor = models['clip_processor']
    faiss_index = models['faiss']
    product_map_df = models['product_map']
    vibe_classifier = models['vibe_classifier']
    VIBES_LIST = models['vibes_list']
    device = models['device']

    # --- Step 1: Vibe Classification (if caption is provided) ---
    vibes = classify_vibes(caption_text, vibe_classifier, VIBES_LIST)

    # --- Step 2: Frame Extraction ---
    # Handles both video and image inputs, returning a list of PIL Images.
    frames = get_frames_from_media(media_path)
    if not frames:
        return {"error": f"Could not load frames/image from {os.path.basename(media_path)}."}

    # --- Step 3: Object Detection ---
    # Finds and crops all relevant fashion items from the frames.
    cropped_items = detect_and_crop_items(frames, yolo_model)

    # --- Step 4: Product Matching and De-duplication ---
    # Finds the best catalog match for each detected item and keeps only the
    # highest-confidence match for each unique product ID.
    final_products = {}
    for item_image in cropped_items:
        match = find_best_match(item_image, clip_model, clip_processor, faiss_index, product_map_df, device)
        if match:
            pid = match['matched_product_id']
            if pid not in final_products or match['confidence'] > final_products[pid]['confidence']:
                final_products[pid] = match

    # --- Step 5: Format Final Output ---
    # Assembles the results into the required JSON structure.
    products_output_list = []
    for prod_id, prod_data in final_products.items():
        match_type = "exact" if prod_data['confidence'] >= EXACT_MATCH_THRESHOLD else "similar"
        products_output_list.append({
            "type": prod_data['type'],
            "color": prod_data['color'],
            "matched_product_id": prod_data['matched_product_id'],
            "match_type": match_type,
            "confidence": round(prod_data['confidence'], 2)
        })

    output_data = {
        "video_id": os.path.basename(media_path).replace('.', '_'),
        "vibes": vibes,
        "products": products_output_list
    }
    return output_data


# ==============================================================================
# 2. HELPER FUNCTIONS
# ==============================================================================
def get_frames_from_media(media_path):
    """Extracts frames from a video file or loads a single image file."""
    if media_path.lower().endswith(('.mp4', '.mov', '.avi')):
        frames = []
        cap = cv2.VideoCapture(media_path)
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(fps) if fps > 0 else 1  # Sample 1 frame per second.
        frame_count = 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            if frame_count % frame_interval == 0:
                # Convert from OpenCV's BGR to PIL's standard RGB format.
                frames.append(Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)))
            frame_count += 1
        cap.release()
        return frames
    elif media_path.lower().endswith(('.png', '.jpg', '.jpeg')):
        return [Image.open(media_path).convert("RGB")]
    return []


def detect_and_crop_items(frames, yolo_model):
    """Detects and crops items from a list of frames using YOLOv8."""
    detected_items = []
    results = yolo_model(frames, conf=YOLO_CONFIDENCE_THRESHOLD, verbose=False)
    for i, r in enumerate(results):
        for box in r.boxes:
            class_name = yolo_model.names[int(box.cls[0])]
            if class_name in YOLO_CLASS_MAP:
                # Crop the detected item from its frame using bounding box coordinates.
                bbox_coords = box.xyxy[0].cpu().numpy()
                cropped_image = frames[i].crop(bbox_coords)
                detected_items.append(cropped_image)
    return detected_items


def find_best_match(cropped_image, clip_model, clip_processor, faiss_index, product_map_df, device):
    """Finds the best product match for a cropped image using CLIP and FAISS."""
    with torch.no_grad():
        # Generate a CLIP embedding for the cropped item.
        inputs = clip_processor(images=cropped_image, return_tensors="pt").to(device)
        image_features = clip_model.get_image_features(**inputs)
        # Normalize the embedding for cosine similarity search.
        image_features /= image_features.norm(p=2, dim=-1, keepdim=True)

    query_embedding = image_features.cpu().numpy()
    # Search the FAISS index for the top 1 nearest neighbor.
    distances, indices = faiss_index.search(query_embedding, k=1)

    similarity = float(distances[0][0])
    if similarity >= MATCH_SIMILARITY_THRESHOLD:
        match_index = indices[0][0]
        matched_product_details = product_map_df.iloc[match_index]
        return {
            "matched_product_id": int(matched_product_details['product_id']),
            "type": matched_product_details['category'],
            "color": matched_product_details['color'],
            "confidence": similarity
        }
    return None

def classify_vibes(caption_text, classifier, vibe_list):
    """Classifies vibes from a caption using a hybrid rule-based/ML approach."""
    if not caption_text or not caption_text.strip() or not vibe_list:
        return []
    # 1. Fast, Rule-Based Check for exact keyword matches.
    found_vibes = [vibe for vibe in vibe_list if vibe.lower() in caption_text.lower()]
    if found_vibes:
        return found_vibes[:3]
    # 2. ML-Based Fallback if no keywords are found.
    try:
        result = classifier(caption_text, vibe_list, multi_label=True)
        confident_vibes = [label for label, score in zip(result['labels'], result['scores']) if score > 0.60]
        # Always return 1-3 vibes as per hackathon rules.
        if confident_vibes:
            return confident_vibes[:3]
        else:
            return [result['labels'][0]] # Return the single best guess.
    except Exception as e:
        print(f"  > WARNING: NLP model failed with an exception: {e}")
        return []