# ==============================================================================
# Flickd AI Hackathon - Web Application
#
# Author: Lasya
# Date: 08/06/2025
#
# Description:
# This script launches a Gradio web interface to demonstrate the Flickd AI
# Smart Tagging and Vibe Classification engine. It allows users to upload
# a video or image and view the AI-generated analysis in real-time.
#
# The application loads all necessary AI models into memory once at startup for
# efficiency and then uses the `processing_logic.py` module to handle the
# core machine learning pipeline for each user request.
# ==============================================================================

# --- Core Libraries ---
import os
import json
import gradio as gr
import pandas as pd
import torch

# --- AI/ML Libraries ---
import faiss
from ultralytics import YOLO
from transformers import CLIPProcessor, CLIPModel, pipeline

# --- Custom Module Import ---
# Imports the main processing function from our backend logic file.
from processing_logic import run_full_pipeline


# ==============================================================================
# 1. CONFIGURATION
#
# Defines all necessary paths and model identifiers.
# ==============================================================================
# --- File Paths ---
CATALOG_IMAGES_DIR = 'data/catalog_images/'
FAISS_INDEX_PATH = 'models/catalog.index'
PRODUCT_MAP_PATH = 'models/product_map.json'
VIBES_LIST_PATH = 'data/vibeslist.json'

# --- Pre-trained Model Identifiers ---
YOLO_MODEL_NAME = 'yolov8n.pt'
CLIP_MODEL_NAME = "openai/clip-vit-base-patch32"
NLP_MODEL_NAME = "facebook/bart-large-mnli"


# ==============================================================================
# 2. GLOBAL MODEL INITIALIZATION
#
# All AI models and data files are loaded into a single dictionary (`MODELS`)
# at application startup. This is a crucial optimization to avoid reloading
# heavy models on every user request, ensuring a fast and responsive UI.
# ==============================================================================
print("Initializing Flickd AI Engine for Web Application...")
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using compute device: {device}")

MODELS = {
    "yolo": YOLO(YOLO_MODEL_NAME).to(device),
    "clip": CLIPModel.from_pretrained(CLIP_MODEL_NAME).to(device),
    "clip_processor": CLIPProcessor.from_pretrained(CLIP_MODEL_NAME),
    "faiss": faiss.read_index(FAISS_INDEX_PATH),
    "product_map": pd.read_json(PRODUCT_MAP_PATH),
    "vibe_classifier": pipeline("zero-shot-classification", model=NLP_MODEL_NAME, device=device),
    "vibes_list": [],  # To be populated from vibes_list.json
    "device": device
}
try:
    with open(VIBES_LIST_PATH, 'r') as f:
        MODELS["vibes_list"] = json.load(f)
except FileNotFoundError:
    print(f"WARNING: Vibe list not found at '{VIBES_LIST_PATH}'. Vibe classification will be disabled.")

print("All models loaded successfully. Launching UI...")


# ==============================================================================
# 3. GRADIO INTERFACE FUNCTION
#
# This function acts as the bridge between the Gradio UI and the backend ML
# pipeline. It receives the user's uploaded file, calls the processing logic,
# and formats the results for display in the UI's output components.
# ==============================================================================
def gradio_interface_function(media_filepath):
    """
    Takes an uploaded file path from the Gradio interface, runs the full ML pipeline,
    and returns the results formatted for the UI's output components.

    Args:
        media_filepath (str): The temporary path to the user's uploaded file.

    Returns:
        tuple: A tuple containing the raw JSON output and a list of file paths
               for the matched product images gallery.
    """
    if media_filepath is None:
        # Return a value for each output component to clear the UI.
        return None, None

    # 1. Execute the core ML pipeline using the pre-loaded models.
    result_json = run_full_pipeline(media_filepath, MODELS)

    # 2. Handle cases with no product matches or errors.
    if not result_json or "products" not in result_json or not result_json["products"]:
        return result_json, []  # Return JSON and an empty list for the gallery.

    # 3. Post-process results to create a list of local image paths for the gallery.
    matched_image_paths = []
    for product in result_json["products"]:
        product_id = product["matched_product_id"]
        image_path = os.path.join(CATALOG_IMAGES_DIR, f"{product_id}.jpg")

        if os.path.exists(image_path):
            matched_image_paths.append(image_path)
        else:
            print(f"WARNING: Catalog image not found for product ID {product_id} at path: {image_path}")

    # 4. Return the processed data to the respective UI output components.
    return result_json, matched_image_paths


# ==============================================================================
# 4. UI CONSTRUCTION AND LAUNCH
#
# Defines the layout and behavior of the Gradio web application.
# ==============================================================================
if __name__ == "__main__":
    iface = gr.Interface(
        fn=gradio_interface_function,
        
        # Define the input component for file uploads.
        inputs=gr.File(label="Upload Video or Image", type="filepath"),
        
        # Define the output components: a JSON viewer and an image gallery.
        outputs=[
            gr.JSON(label="Analysis Results (JSON)"),
            gr.Gallery(
                label="Matched Product Images",
                columns=5,
                object_fit="contain",
                height="auto"
            )
        ],
        
        # Configure the UI's title, description, and example files.
        title="Flickd AI 🛍️ Smart Tagging Engine",
        description="Upload a short fashion video (.mp4) or an image (.jpg, .png) to automatically detect products. The matched product images from our catalog will be displayed below.",
        examples=[
            ['data/media_inputs/2025-05-27_13-46-16_UTC.mp4'],
            ['data/media_inputs/2025-05-27_13-46-16_UTC.jpg']
        ],
        allow_flagging="never" # Disables the flagging feature for a cleaner UI.
    )

    # Launch the web application.
    iface.launch()