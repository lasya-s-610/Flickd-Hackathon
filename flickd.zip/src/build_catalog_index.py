import pandas as pd
import os
import torch
import faiss
import numpy as np
import re
from PIL import Image
from transformers import CLIPProcessor, CLIPModel
from tqdm import tqdm

# --- CONFIGURATION ---
CATALOG_EXCEL_PATH = 'development/data/product_data.xlsx'
CATALOG_IMAGES_DIR = 'development/data/catalog_images/'
FAISS_INDEX_PATH = 'development/models/catalog.index'
PRODUCT_MAP_PATH = 'development/models/product_map.json'
MODEL_NAME = "openai/clip-vit-base-patch32"

def parse_color_from_tags(tags_string):
    """Extracts color from a string like 'Colour:Purple, Fabric:...'"""
    if not isinstance(tags_string, str):
        return "unknown"
    match = re.search(r"Colour:(\w+)", tags_string, re.IGNORECASE) # Ignore case for 'Colour'
    return match.group(1).lower() if match else "unknown"

def build_and_save_index():
    """
    Generates CLIP embeddings for the product catalog and saves them
    into a FAISS index and a product metadata map, using only products
    that have both data in Excel and a corresponding image.
    """
    # 1. Load AI Models
    print("Loading CLIP model...")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = CLIPModel.from_pretrained(MODEL_NAME).to(device)
    processor = CLIPProcessor.from_pretrained(MODEL_NAME)
    print(f"Models loaded on {device}.")

    # 2. Find the intersection of catalog data and available images
    print("Finding intersection of catalog data and images...")
    df = pd.read_excel(CATALOG_EXCEL_PATH)
    
    # Get IDs from Excel. Ensure they are strings for comparison with filenames.
    excel_ids = set(df['id'].astype(str))
    
    # Get IDs from image filenames (e.g., '14976.jpg' -> '14976')
    image_ids = set(os.path.splitext(f)[0] for f in os.listdir(CATALOG_IMAGES_DIR))
    
    # Find the common IDs
    valid_ids = excel_ids.intersection(image_ids)
    
    print(f"Found {len(df)} rows in Excel.")
    print(f"Found {len(image_ids)} images in directory.")
    print(f"Found {len(valid_ids)} common products to process.")

    if not valid_ids:
        print("No common products found. Exiting.")
        return
        
    # Filter the DataFrame to only include products we have images for.
    # Convert 'id' column to string for the .isin() check to work correctly.
    df_filtered = df[df['id'].astype(str).isin(valid_ids)].copy()


    # 3. Generate Embeddings and Metadata for the filtered products
    product_map_data = []
    all_embeddings = []

    print("Generating embeddings for the valid catalog images...")
    with torch.no_grad():
        # Iterate over the clean, filtered DataFrame
        for index, row in tqdm(df_filtered.iterrows(), total=len(df_filtered), desc="Processing Catalog"):
            product_id_str = str(row['id'])
            image_path = os.path.join(CATALOG_IMAGES_DIR, f"{product_id_str}.jpg")

            # We are now guaranteed that the image exists, so no need for os.path.exists() check
            try:
                image = Image.open(image_path).convert("RGB")
                inputs = processor(images=image, return_tensors="pt").to(device)
                image_features = model.get_image_features(**inputs)
                all_embeddings.append(image_features.cpu().numpy())
            except Exception as e:
                print(f"Error processing image for ID {product_id_str}: {e}")
                # In case of a corrupted image file, we skip this entry
                continue

            # Store metadata for this product
            product_map_data.append({
                'product_id': row['id'],
                'title': row['title'],
                'category': row['product_type'],
                'color': parse_color_from_tags(row.get('product_tags', ''))
            })

    if not all_embeddings:
        print("No embeddings were successfully generated. Exiting.")
        return

    # 4. Build and Save FAISS Index
    embeddings_matrix = np.vstack(all_embeddings)
    faiss.normalize_L2(embeddings_matrix)
    
    embedding_dim = embeddings_matrix.shape[1]
    index = faiss.IndexFlatIP(embedding_dim)
    index.add(embeddings_matrix)
    
    os.makedirs('models', exist_ok=True)
    faiss.write_index(index, FAISS_INDEX_PATH)
    print(f"FAISS index with {index.ntotal} vectors saved to {FAISS_INDEX_PATH}")

    # 5. Save the Product Metadata Map
    pd.DataFrame(product_map_data).to_json(PRODUCT_MAP_PATH, orient='records', indent=2)
    print(f"Product map with {len(product_map_data)} entries saved to {PRODUCT_MAP_PATH}")

if __name__ == "__main__":
    build_and_save_index()